# WoA Arcane Realm — Asset Starter Pack

This pack organizes the generated concept sheet into useful visual-reference panels.

## Important
These panel crops are **reference images**, not clean, game-ready sprite atlases. The original sheet contains mixed panel borders, labels, effects, and sprites at inconsistent sizes. Do not load a whole panel as an animated character spritesheet.

## Recommended next steps
1. Open the relevant reference crop while drawing in Piskel.
2. Redraw or carefully isolate one character on a transparent canvas.
3. Keep each animation frame the same size (start with 32x48 only if the character fits; otherwise use a consistent larger frame such as 48x64).
4. Export each animation as a transparent PNG spritesheet.
5. In the game, define the frame dimensions and animation names explicitly.

## Suggested initial production assets
- `player/wizard_idle.png`
- `player/wizard_walk.png`
- `player/wizard_run.png`
- `player/wizard_attack.png`
- `player/wizard_cast.png`
- `mathias/mathias_idle.png`
- `enemies/shadow_wraith_idle.png`
- `effects/magic_bolt.png`
- `portals/arcane_portal.png`

Use the full concept sheet as the art-direction source and the cropped panels as drawing references.
